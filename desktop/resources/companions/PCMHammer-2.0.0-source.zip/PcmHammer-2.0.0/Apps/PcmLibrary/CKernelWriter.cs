﻿// SPDX-License-Identifier: GPL-3.0-only
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PcmHacking
{
    /// <summary>
    /// How much of the PCM to erase and rewrite.
    /// </summary>
    public enum WriteType
    {
        None = 0,
        Compare,
        TestWrite,
        Calibration,
        Parameters,
        OsPlusCalibrationPlusBoot,
        Full,
    }

    public class CKernelWriter
    {
        private readonly Vehicle vehicle;
        private readonly OSIDInfo pcmInfo;
        private readonly Protocol protocol;
        private readonly WriteType writeType;
        private readonly ILogger logger;

        // How much of the flash chip we will verify and (re)write. Set once the chip is identified
        // in Write(). Normally the detected chip size, not the (possibly smaller) PCM-type default.
        private UInt32 effectiveImageSize;

        public CKernelWriter(Vehicle vehicle, OSIDInfo pcmInfo, Protocol protocol, WriteType writeType, ILogger logger)
        {
            this.vehicle = vehicle;
            this.pcmInfo = pcmInfo;
            this.protocol = protocol;
            this.writeType = writeType;
            this.logger = logger;
        }

        /// <summary>
        /// Write changes to the PCM's flash memory, or just test writing (Without 
        /// making changes) to evaluate the connection quality.
        /// </summary>
        public async Task<bool> Write(
            byte[] image,
            UInt64 kernelVersion,
            FileValidator validator,
            bool needToCheckOperatingSystem,
            CancellationToken cancellationToken)
        {
            bool success = false;

            try
            {
                // Start with known state.
                await this.vehicle.ForceSendToolPresentNotification();
                this.vehicle.ClearDeviceMessageQueue();

                // TODO: install newer version if available.
                if (kernelVersion == 0)
                {
                    // Switch to 4x, if possible. But continue either way.
                    if (this.vehicle.Enable4xReadWrite)
                    {
                        // if the vehicle bus switches but the device does not, the bus will need to time out to revert back to 1x, and the next steps will fail.
                        if (!await this.vehicle.VehicleSetVPW4x(this.pcmInfo, VpwSpeed.FourX))
                        {
                            logger.AddUserMessage("Stopping here because we were unable to switch to 4X.");
                            return false;
                        }
                    }
                    else
                    {
                        logger.AddUserMessage("4X communications disabled by configuration.");
                    }

                    await this.vehicle.SendToolPresentNotification();

                    Response<byte[]> response;

                    // Execute kernel loader, if required
                    if (this.pcmInfo.LoaderRequired)
                    {
                        response = await vehicle.LoadKernelFromFile(this.pcmInfo.LoaderFileName);
                        if (response.Status != ResponseStatus.Success)
                        {
                            logger.AddUserMessage("Failed to load loader from file.");
                            return false;
                        }
                        logger.AddUserMessage("Kernel loader loaded from file.");

                        if (cancellationToken.IsCancellationRequested)
                        {
                            return false;
                        }

                        await this.vehicle.SendToolPresentNotification();

                        if (!await this.vehicle.PCMExecute(this.pcmInfo, response.Value, cancellationToken))
                        {
                            logger.AddUserMessage("Failed to upload loader to PCM");

                            return false;
                        }

                        logger.AddUserMessage("Loader uploaded to PCM successfully.");
                    }

                    response = await this.vehicle.LoadKernelFromFile(this.pcmInfo.KernelFileName);
                    if (response.Status != ResponseStatus.Success)
                    {
                        logger.AddUserMessage("Failed to load kernel from file.");
                        return false;
                    }
                    logger.AddUserMessage("Kernel loaded from file.");

                    if (cancellationToken.IsCancellationRequested)
                    {
                        return false;
                    }

                    if (!await this.vehicle.PCMExecute(this.pcmInfo, response.Value, cancellationToken))
                    {
                        logger.AddUserMessage("Failed to upload kernel to PCM");

                        return false;
                    }

                    logger.AddUserMessage("Kernel uploaded to PCM successfully.");
                }

                // Confirm operating system match
                await this.vehicle.SendToolPresentNotification();
                await this.vehicle.SetDeviceTimeout(TimeoutScenario.ReadProperty);
                Response<UInt32> osidResponse = await this.vehicle.QueryOperatingSystemIdFromKernel(cancellationToken);
                if (needToCheckOperatingSystem && (osidResponse.Status != ResponseStatus.Success))
                {
                    // The kernel seems broken. This shouldn't happen, but if it does, halt.
                    logger.AddUserMessage("The kernel did not respond to operating system ID query.");
                    return false;
                }

                Utility.ReportOperatingSystems(validator.GetOsidFromImage(), osidResponse.Value, this.writeType, this.logger, out bool shouldHalt);
                if (needToCheckOperatingSystem && shouldHalt)
                {
                    return false;
                }

                success = await this.Write(cancellationToken, image);

                // We only do cleanup after a successful write.
                // If the kernel remains running, the user can try to flash again without rebooting and reloading.
                // TODO: kernel version should be stored at a fixed location in the bin file.
                // TODO: app should check kernel version (not just "is present") and reload only if version is lower than version in kernel file.
                if (success)
                {
                    await this.vehicle.Cleanup();
                }

                return success;
            }
            catch (Exception exception)
            {
                if (!success)
                {
                    switch (this.writeType)
                    {
                        case WriteType.None:
                        case WriteType.Compare:
                        case WriteType.TestWrite:
                            await this.vehicle.Cleanup();
                            logger.AddUserMessage("Something has gone wrong. Please report this error.");
                            logger.AddUserMessage("Errors during comparisons or test writes indicate a");
                            logger.AddUserMessage("problem with the PCM, interface, cable, or app. Don't");
                            logger.AddUserMessage("try to do any actual writing until you are certain that");
                            logger.AddUserMessage("the underlying problem has been completely corrected.");
                            break;

                        default:
                            logger.AddUserMessage("Something went wrong. " + exception.Message);
                            logger.AddUserMessage("Do not power off the PCM! Do not exit this program!");
                            logger.AddUserMessage("Try flashing again. If errors continue, seek help online.");
                            break;
                    }

                    logger.AddUserMessage("https://pcmhacking.net/forums/viewtopic.php?f=42&t=6080");
                    logger.AddUserMessage(string.Empty);
                    logger.AddUserMessage(exception.ToString());
                }

                return success;
            }
            finally
            {
                logger.StatusUpdateReset();
            }
        }

        /// <summary>
        /// Write the calibration blocks.
        /// </summary>
        private async Task<bool> Write(CancellationToken cancellationToken, byte[] image)
        {
            await this.vehicle.SendToolPresentNotification();

            BlockType relevantBlocks;
            switch (this.writeType)
            {
                case WriteType.Compare:
                    relevantBlocks = BlockType.All;
                    break;

                case WriteType.TestWrite:
                    relevantBlocks = BlockType.Calibration;
                    break;

                case WriteType.Calibration:
                    relevantBlocks = BlockType.Calibration;
                    break;

                case WriteType.Parameters:
                    relevantBlocks = BlockType.Parameter;
                    break;

                case WriteType.OsPlusCalibrationPlusBoot:
                    // Overwriting parameter blocks would break the EBCM pairing, 
                    // which is not what most users want. They just want a new OS 
                    // and the calibration to go along with it.
                    //
                    // The cast seems redundant, but C# converts the enum values 
                    // to ints when it does arithmetic.
                    relevantBlocks = (BlockType)(BlockType.All - BlockType.Parameter);
                    break;

                case WriteType.Full:
                    relevantBlocks = BlockType.All;
                    break;

                default:
                    throw new InvalidDataException("Unsuppported operation type: " + this.writeType.ToString());
            }

            // Which flash chip?
            await this.vehicle.SendToolPresentNotification();
            Response<UInt32> chipIdResponse = await this.vehicle.QueryFlashChipId(cancellationToken);
            if (chipIdResponse.Status != ResponseStatus.Success)
            {
                await this.vehicle.Cleanup();
                return false;
            }

            FlashChip flashChip = FlashChip.Create(chipIdResponse.Value, this.logger);
            logger.AddUserMessage("Flash chip: " + flashChip.ToString());

            // A P10/P11 can have a 1Mb chip while using 512KiB images, so that can be allowed
            // This originally was to prevent cross flashing between P01 and P59 but we have now split those types
            // Still a good safety check
            if ((pcmInfo.HardwareType == PcmType.P10 || pcmInfo.HardwareType == PcmType.P11) &&
                image.Length == 512 * 1024 &&
                flashChip.Size == 1024 * 1024)
            {
                logger.AddUserMessage(string.Format("File size {0:n0} for flash chip size {1:n0}. Allowable for {2}.", image.Length, flashChip.Size, pcmInfo.HardwareType));
            }
            else if (image.Length != flashChip.Size)
            {
                logger.AddUserMessage(string.Format("File size {0:n0} does not match flash chip size {1:n0}. This image is not compatible with this PCM.", image.Length, flashChip.Size));
                await this.vehicle.Cleanup();
                return false;
            }

            // Decide how much of the chip we will verify and (re)write. Use the detected flash
            // chip size rather than the PCM-type default size: the default can be too small (e.g.
            // a P04_Early defaults to 256KiB but may physically carry a 512KiB chip), which would
            // otherwise leave the upper half unwritten and unverified. The P10/P11 are the
            // intentional exception - they carry a larger chip than they use (only the lower
            // 512KiB is wired up), so we keep the smaller PCM-type size for those. The size check
            // above guarantees the file matches whichever size we settle on, so we never read past
            // the end of the image below. This mirrors the read path in CKernelReader.
            if (pcmInfo.HardwareType == PcmType.P10 || pcmInfo.HardwareType == PcmType.P11)
            {
                this.effectiveImageSize = (UInt32)this.pcmInfo.ImageSize;
            }
            else
            {
                this.effectiveImageSize = flashChip.Size;
            }

            CKernelVerifier verifier = new CKernelVerifier(
                image,
                flashChip.MemoryRanges,
                this.vehicle,
                this.protocol,
                this.pcmInfo,
                this.effectiveImageSize,
                this.logger);

            bool allRangesMatch = false;
            int messageRetryCount = 0;
            await this.vehicle.SendToolPresentNotification();
            for (int attempt = 1; attempt <= 5; attempt++)
            {
                logger.StatusUpdateReset();

                CrcVerificationResult verificationResult = await verifier.CompareRanges(
                    image,
                    relevantBlocks,
                    cancellationToken);

                if (verificationResult == CrcVerificationResult.Timeout)
                {
                    logger.AddUserMessage("PCM stopped responding during write verification. Aborting.");
                    return false;
                }

                if (verificationResult == CrcVerificationResult.Verified)
                {
                    allRangesMatch = true;

                    // Don't stop here if the user just wants to test their cable.
                    if (this.writeType == WriteType.TestWrite)
                    {
                        if (attempt == 1)
                        {
                            logger.AddUserMessage("Beginning test.");
                        }
                    }
                    else
                    {
                        logger.AddUserMessage("All relevant ranges are identical.");
                        if (attempt > 1)
                        {
                            Utility.ReportRetryCount("Write", messageRetryCount, pcmInfo.ImageSize, this.logger);
                        }
                        break;
                    }
                }

                // For test writes, report results after the first iteration, then we're done.
                if ((this.writeType == WriteType.TestWrite) && (attempt > 1))
                {
                    logger.AddUserMessage("Test write complete.");
                    Utility.ReportRetryCount("Write", messageRetryCount, pcmInfo.ImageSize, this.logger);
                    return true;
                }

                // Stop now if the user only requested a comparison.
                if (this.writeType == WriteType.Compare)
                {
                    logger.AddUserMessage("Note that mismatched Parameter blocks are to be expected.");
                    logger.AddUserMessage("Parameter data can change every time the PCM is used.");
                    return true;
                }

                // Preflight policy gate: block before any erase/write if this PCM
                // does not allow boot-sector writes and boot would be written.
                if (!this.IsWritePlanAllowedByPcmInfo(flashChip, relevantBlocks))
                {
                    logger.AddUserMessage("Boot sector write is required for this operation.");
                    logger.AddUserMessage($"Abort: The {this.pcmInfo.HardwareType} boot sector is write protected. This PCM is not compatible with this file.");
                    await this.vehicle.Cleanup();
                    return false;
                }

                // Erase and rewrite the required memory ranges.
                DateTime startTime = DateTime.Now;
                UInt32 totalSize = this.GetTotalSize(flashChip, relevantBlocks);
                UInt32 bytesRemaining = totalSize;
                foreach (MemoryRange range in flashChip.MemoryRanges)
                {
                    // We'll send a tool-present message during the erase request.
                    if (!this.ShouldProcess(range, relevantBlocks))
                    {
                        continue;
                    }

                    logger.AddUserMessage(
                        string.Format(
                            "Processing range {0:X6}-{1:X6}",
                            range.Address,
                            range.Address + (range.Size - 1)));

                    if (cancellationToken.IsCancellationRequested)
                    {
                        logger.AddUserMessage("Cancelled before erase.");
                        return false;
                    }

                    if (this.writeType == WriteType.TestWrite)
                    {
                        logger.AddUserMessage("Pretending to erase.");
                    }
                    else
                    {
                        if (!await this.EraseMemoryRange(range, cancellationToken))
                        {
                            return false;
                        }
                    }

                    if (this.writeType == WriteType.TestWrite)
                    {
                        logger.AddUserMessage("Pretending to write...");
                    }
                    else
                    {
                        logger.AddUserMessage("Writing...");
                    }

                    Response<bool> writeResponse = await WriteMemoryRange(
                        range,
                        image,
                        this.writeType == WriteType.TestWrite,
                        startTime,
                        totalSize,
                        bytesRemaining,
                        cancellationToken);

                    if (writeResponse.RetryCount > 0)
                    {
                        logger.AddUserMessage("Retry count for this block: " + writeResponse.RetryCount);
                        messageRetryCount += writeResponse.RetryCount;
                    }

                    logger.StatusUpdateRetryCount((messageRetryCount > 0) ? messageRetryCount.ToString() + ((messageRetryCount > 1) ? " Retries" : " Retry") : string.Empty);

                    if (writeResponse.Value)
                    {
                        bytesRemaining -= range.Size;
                    }
                }
            }

            if (allRangesMatch)
            {
                if (this.writeType != WriteType.Compare && this.writeType != WriteType.TestWrite)
                {
                    logger.AddUserMessage("Flash successful!");
                }
                return true;
            }

            // During a test write, we will return from the middle of the loop above.
            // So if we made it here, a real write has failed.
            logger.AddUserMessage("===============================================");
            logger.AddUserMessage("THE CHANGES WERE -NOT- WRITTEN SUCCESSFULLY");
            logger.AddUserMessage("===============================================");

            if (this.writeType == WriteType.Calibration)
            {
                logger.AddUserMessage("Erasing Calibration to force recovery mode.");
                logger.AddUserMessage("");

                foreach(MemoryRange range in flashChip.MemoryRanges)
                {
                    if (range.Type == BlockType.Calibration)
                    {
                        await this.EraseMemoryRange(range, cancellationToken);
                    }
                }
            }

            if (cancellationToken.IsCancellationRequested)
            {
                logger.AddUserMessage("");
                logger.AddUserMessage("The operation was cancelled.");
                logger.AddUserMessage("This PCM is probably not usable in its current state.");
                logger.AddUserMessage("");
            }
            else
            {
                logger.AddUserMessage("This may indicate a hardware problem on the PCM.");
                logger.AddUserMessage("We tried, and re-tried, and it still didn't work.");
                logger.AddUserMessage("");
                logger.AddUserMessage("Please start a new thread at pcmhacking.net, and");
                logger.AddUserMessage("include the contents of the debug tab.");
                this.RequestDebugLogs(cancellationToken);
            }

            return false;
        }

        private UInt32 GetTotalSize(FlashChip chip, BlockType relevantBlocks)
        {
            UInt32 result = 0;
            foreach(MemoryRange range in chip.MemoryRanges)
            {
                if (this.ShouldProcess(range, relevantBlocks))
                {
                    result += range.Size;
                }
            }

            return result;
        }

        private bool ShouldProcess(MemoryRange range, BlockType relevantBlocks)
        {
            if ((range.ActualCrc == range.DesiredCrc) && (this.writeType != WriteType.TestWrite))
            {
                return false;
            }

            // The P10 has the same flash chip as the P59, but the high bit of the address bus
            // isn't connected, so there will be hardware errors talking to the top 512kb.
            // So, we skip ranges that are beyond the size of the usable image. For most PCMs the
            // usable size is the whole detected chip; for P10/P11 it is the smaller PCM-type size.
            if (range.Address >= this.effectiveImageSize)
            {
                return false;
            }

            // Skip irrelevant blocks.
            if ((range.Type & relevantBlocks) == 0)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Check write plan against PCM policy before any erase/write occurs.
        /// </summary>
        private bool IsWritePlanAllowedByPcmInfo(FlashChip flashChip, BlockType relevantBlocks)
        {
            // Compare and test-write are non-destructive.
            if (this.writeType == WriteType.Compare || this.writeType == WriteType.TestWrite)
            {
                return true;
            }

            // Boot sector writes are supported; allow all write plans.
            if (this.pcmInfo.IsSupportedWriteBootSector)
            {
                return true;
            }

            foreach (MemoryRange range in flashChip.MemoryRanges)
            {
                // ShouldProcess means this range is relevant AND differs (for real writes).
                if (!this.ShouldProcess(range, relevantBlocks))
                {
                    continue;
                }

                // Block attempts to write boot sector on PCMs that do not support it
                if ((range.Type & BlockType.Boot) != 0)
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// Erase a block in the flash memory.
        /// </summary>
        private async Task<bool> EraseMemoryRange(MemoryRange range, CancellationToken cancellationToken)
        {
            logger.AddUserMessage("Erasing.");

            await this.vehicle.SetDeviceTimeout(TimeoutScenario.EraseMemoryBlock);
            Query<byte> eraseRequest = this.vehicle.CreateQuery<byte>(
                 () => this.protocol.CreateFlashEraseBlockRequest(range.Address),
                 this.protocol.ParseFlashEraseBlock,
                 cancellationToken);

            eraseRequest.MaxTimeouts = 3;
            Response<byte> eraseResponse = await eraseRequest.Execute();

            if (eraseResponse.Status != ResponseStatus.Success)
            {
                logger.AddUserMessage("Unable to erase flash memory: " + eraseResponse.Status.ToString());
                this.RequestDebugLogs(cancellationToken);
                return false;
            }

            if (eraseResponse.Value != 0x00)
            {
                logger.AddUserMessage("Unable to erase flash memory. Code: " + eraseResponse.Value.ToString("X2"));
                this.RequestDebugLogs(cancellationToken);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Copy a single memory range to the PCM.
        /// </summary>
        private async Task<Response<bool>> WriteMemoryRange(
            MemoryRange range,
            byte[] image,
            bool justTestWrite,
            DateTime startTime,
            UInt32 totalSize,
            UInt32 bytesRemaining,
            CancellationToken cancellationToken)
        {
            int retryCount = 0;
            int devicePayloadSize = vehicle.DeviceMaxFlashWriteSendSize - 12; // Headers use 10 bytes, sum uses 2 bytes.
            for (int index = 0; index < range.Size; index += devicePayloadSize)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    return Response.Create(ResponseStatus.Cancelled, false, retryCount);
                }

                await this.vehicle.SendToolPresentNotification();

                int startAddress = (int)(range.Address + index);
                UInt32 thisPayloadSize = (UInt32) Math.Min(devicePayloadSize, (int)range.Size - index);

                logger.AddDebugMessage(
                    string.Format(
                        "Sending payload with offset 0x{0:X4}, start address 0x{1:X6}, length 0x{2:X4}.",
                        index,
                        startAddress,
                        thisPayloadSize));

                Message payloadMessage = protocol.CreateBlockMessage(
                    image,
                    startAddress,
                    (int)thisPayloadSize,
                    startAddress,
                    justTestWrite ? BlockCopyType.TestWrite : BlockCopyType.Copy);

                string timeRemaining = string.Empty;

                TimeSpan elapsed = DateTime.Now - startTime;
                UInt32 totalWritten = totalSize - bytesRemaining;
                UInt32 bytesPerSecond = 0;

                bytesPerSecond = (UInt32)(totalWritten / elapsed.TotalSeconds);

                // Don't divide by zero.
                if (bytesPerSecond > 0)
                {
                    UInt32 secondsRemaining = (UInt32)(bytesRemaining / bytesPerSecond);
                    timeRemaining = TimeSpan.FromSeconds(secondsRemaining).ToString("mm\\:ss");
                }

                logger.StatusUpdateActivity($"Writing {thisPayloadSize} bytes to 0x{startAddress:X6}");
                logger.StatusUpdatePercentDone((totalWritten * 100 / totalSize > 0) ? $"{totalWritten * 100 / totalSize}%" : string.Empty);
                logger.StatusUpdateTimeRemaining($"T-{timeRemaining}");
                logger.StatusUpdateKbps((bytesPerSecond > 0) ? $"{(double)bytesPerSecond * 8.00 / 1000.00:0.00} Kbps" : string.Empty);
                logger.StatusUpdateProgressBar((double)(totalWritten + thisPayloadSize) / totalSize, true);

                await this.vehicle.SetDeviceTimeout(TimeoutScenario.WriteMemoryBlock);

                // WritePayload contains a retry loop, so if it fails, we don't need to retry at this layer.
                Response<bool> response = await this.vehicle.WritePayload(payloadMessage, cancellationToken);
                if (response.Status != ResponseStatus.Success)
                {
                    return Response.Create(ResponseStatus.Error, false, response.RetryCount);
                }

                bytesRemaining -= thisPayloadSize;
                retryCount += response.RetryCount;
            }

            return Response.Create(ResponseStatus.Success, true, retryCount);
        }

        /// <summary>
        /// Ask the user for diagnostic information, unless they cancelled.
        private void RequestDebugLogs(CancellationToken cancellationToken)
        {
            if (!cancellationToken.IsCancellationRequested)
            {
                logger.AddUserMessage("Select the debug tab, click anywhere in the text,");
                logger.AddUserMessage("press Ctrl+A to select the text, and Ctrl+C to");
                logger.AddUserMessage("copy the text. Press Ctrl+V to paste that content");
                logger.AddUserMessage("content into your forum post.");
            }
        }
    }
}
