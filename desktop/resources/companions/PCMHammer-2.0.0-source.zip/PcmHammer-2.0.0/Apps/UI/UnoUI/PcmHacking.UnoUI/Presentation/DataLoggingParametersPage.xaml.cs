﻿// SPDX-License-Identifier: GPL-3.0-only
using System.Data;
using System.Data.Common;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using Microsoft.UI;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Shapes;
using PcmHacking.UnoUI.Utilities;
using Uno.Extensions.Reactive;
using Windows.UI.Text;
using Windows.UI.ViewManagement;

namespace PcmHacking.UnoUI.Presentation;

public record Indices(int MainRowIndex, int ZoomRowIndex);
public record DataSource(LogColumn? LogColumn, CanLogger.ParameterAndValue? CanParameter);
public record RowMetadata(DataSource DataSource, Indices Indices, TextBlock Value, TextBlock? ZoomedValue, string Units);

public sealed partial class DataLoggingParametersPage : Page
{
    private List<RowMetadata> parameterMetadata = new();

    private DataLoggingParametersModel? model;

    private DispatcherQueue dispatcherQueue;

    public DataLoggingParametersPage()
    {
        this.dispatcherQueue = DispatcherQueue.GetForCurrentThread();
        this.InitializeComponent();

        this.DataContextChanged += OnDataContextChanged;
        this.Loaded += OnLoaded;
    }

    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        // This can't run in the constructor because the XamlRoot isn't available yet.
        bool darkMode = this.XamlRoot == null ? false : SystemThemeHelper.IsRootInDarkMode(this.XamlRoot);
        ColorUtilities.Initialize(darkMode);
    }

    private void OnDataContextChanged(object sender, DataContextChangedEventArgs e)
    {
        var newModel = (this.DataContext as DataLoggingParametersViewModel)?.Model as DataLoggingParametersModel;
        if (newModel == null)
        {
            return;
        }

        if (newModel == this.model)
        {
            return;
        }

        this.model = newModel;

        this.model.ProgressLogger.AddDebugMessage("DataLoggingParametersPage DataContext set.");

        this.model.LoggerWrapper.ForEach((loggerWrapper, ct) => this.InitializeParameters(loggerWrapper.Logger));

        this.model.Rows.ForEach((row, ct) => this.UpdateParameterValues(row.Values));

        this.model.ErrorMessage.ForEach((value, ct) => this.ShowErrorMessage(value ?? string.Empty));

        // Let the Model know that it's safe to continue.
        this.model.InitializationEvent.Set();
        this.model.ProgressLogger.AddDebugMessage("DataLoggingParametersPage callbacks registered.");
    }

    protected override void OnNavigatingFrom(NavigatingCancelEventArgs e)
    {
        this.model?.StopLogging();
    }

    private void ResetGrid()
    {
        this.Parameters.RowDefinitions.Clear();
        this.ZoomedParameters.RowDefinitions.Clear();
        this.Parameters.Children.Clear();
        this.ZoomedParameters.Children.Clear();
        this.parameterMetadata.Clear();
    }

    // This runs synchronously, but must return a ValueTask to because it's
    // invoked as a .ForEach() callback.
    private ValueTask InitializeParameters(Logger logger)
    {
        if (this.model == null)
        {
            return ValueTask.CompletedTask;
        }

        this.model.ProgressLogger.AddDebugMessage("Initializing parameter grid.");

        // Operations that affect the UI need to run on the main thread.
        this.dispatcherQueue.TryEnqueue(() =>
        {
            this.ResetGrid();

            int mainRowIndex = 0;
            int zoomRowIndex = 0;
            
            foreach (ParameterGroup group in logger.DpidConfiguration.ParameterGroups)
            {
                foreach (LogColumn column in group.LogColumns)
                {
                    this.AddParameter(mainRowIndex, column.Parameter.Name, column.Conversion.Units, out TextBlock valueTextBlock);
                    
                    TextBlock? zoomValue = null;
                    int zoomRow = -1;
                    if (column.Zoom)
                    {
                        this.AddZoomParameter(zoomRowIndex, column.Parameter.Name, column.Conversion.Units, out zoomValue);
                        zoomRow = zoomRowIndex;
                        zoomRowIndex++;
                    }

                    this.parameterMetadata.Add(
                        new RowMetadata(
                            new DataSource(column, null),
                            new Indices(mainRowIndex, zoomRow),
                            valueTextBlock,
                            zoomValue,
                            column.Conversion.Units));

                    mainRowIndex++;
                }
            }

            foreach (LogColumn mathColumn in logger.MathValueProcessor.GetMathColumns())
            {
                this.AddParameter(mainRowIndex, mathColumn.Parameter.Name, mathColumn.Conversion.Units, out TextBlock valueTextBlock);

                TextBlock? zoomValue = null;
                int zoomRow = -1;
                if (mathColumn.Zoom)
                {
                    this.AddZoomParameter(zoomRowIndex, mathColumn.Parameter.Name, mathColumn.Conversion.Units, out zoomValue);
                    zoomRow = zoomRowIndex;
                    zoomRowIndex++;
                }

                this.parameterMetadata.Add(
                    new RowMetadata(
                        new DataSource(mathColumn, null),
                        new Indices(mainRowIndex, zoomRow),
                        valueTextBlock,
                        zoomValue,
                        mathColumn.Conversion.Units));

                mainRowIndex++;
            }

            foreach (CanLogger.ParameterAndValue canParameter in logger.CanLogger.GetParameterValues())
            {
                this.AddParameter(mainRowIndex, canParameter.Parameter.Name, canParameter.Units, out TextBlock valueTextBlock);
                mainRowIndex++;

                this.parameterMetadata.Add(
                    new RowMetadata(
                        new DataSource(null, canParameter),
                        new Indices(mainRowIndex, -1),
                        valueTextBlock,
                        null,
                        canParameter.Units));
            }
        });

        return ValueTask.CompletedTask;
    }

    private void AddParameter(int mainRowIndex, string name, string units, out TextBlock valueTextBlock)
    {
        const int textSize = 30;
        
        TextBlock nameTextBlock = new TextBlock();
        nameTextBlock.Text = name;
        nameTextBlock.FontSize = textSize;
        nameTextBlock.Margin = new Thickness(5);
        nameTextBlock.HorizontalAlignment = HorizontalAlignment.Right;
        nameTextBlock.VerticalAlignment = VerticalAlignment.Center;
        
        Border nameBorder = new Border();
        nameBorder.Background = ColorUtilities.Instance.BackgroundBrushes[mainRowIndex % 2];
        nameBorder.SetValue(Grid.RowProperty, mainRowIndex);
        nameBorder.SetValue(Grid.ColumnProperty, 0);
        nameBorder.Child = nameTextBlock;

        valueTextBlock = new TextBlock();
        valueTextBlock.Text = units;
        valueTextBlock.FontSize = textSize;
        valueTextBlock.FontWeight = new FontWeight(700); // bold
        valueTextBlock.Margin = new Thickness(5);
        valueTextBlock.HorizontalAlignment = HorizontalAlignment.Left;
        valueTextBlock.VerticalAlignment = VerticalAlignment.Center;

        Border valueBorder = new Border();
        valueBorder.Background = ColorUtilities.Instance.BackgroundBrushes[mainRowIndex % 2];
        valueBorder.SetValue(Grid.RowProperty, mainRowIndex);
        valueBorder.SetValue(Grid.ColumnProperty, 1);
        valueBorder.Child = valueTextBlock;

        this.Parameters.RowDefinitions.Add(new RowDefinition());
        this.Parameters.Children.Add(nameBorder);
        this.Parameters.Children.Add(valueBorder);
    }

    private void AddZoomParameter(int zoomRowIndex, string name, string units, out TextBlock? valueTextBlock)
    {
        const int labelSize = 30;
        const int valueSize = 60;
                
        StackPanel stackPanel = new StackPanel();
        stackPanel.Orientation = Orientation.Vertical;
        stackPanel.VerticalAlignment = VerticalAlignment.Center;

        Border border = new Border();
        border.Background = ColorUtilities.Instance.BackgroundBrushes[zoomRowIndex % 2];
        border.SetValue(Grid.RowProperty, zoomRowIndex);
        border.SetValue(Grid.ColumnProperty, 0);
        border.Child = stackPanel;

        TextBlock zoomName = new TextBlock();
        zoomName.Text = name;
        zoomName.FontSize = labelSize;
        zoomName.Margin = new Thickness(5);
        zoomName.HorizontalAlignment = HorizontalAlignment.Center;
        zoomName.VerticalAlignment = VerticalAlignment.Center;
        stackPanel.Children.Add(zoomName);

        valueTextBlock = new TextBlock();
        valueTextBlock.FontSize = valueSize;
        valueTextBlock.Margin = new Thickness(5);
        valueTextBlock.HorizontalAlignment = HorizontalAlignment.Center;
        valueTextBlock.VerticalAlignment = VerticalAlignment.Center;
        valueTextBlock.Text = string.Empty;
        stackPanel.Children.Add(valueTextBlock);

        TextBlock zoomUnits = new TextBlock();
        zoomUnits.Text = units;
        zoomUnits.FontSize = labelSize;
        zoomUnits.Margin = new Thickness(5);
        zoomUnits.HorizontalAlignment = HorizontalAlignment.Center;
        zoomUnits.VerticalAlignment = VerticalAlignment.Center;
        stackPanel.Children.Add(zoomUnits);

        this.ZoomedParameters.RowDefinitions.Add(new RowDefinition());
        this.ZoomedParameters.Children.Add(border);
    }

    private ValueTask UpdateParameterValues(IEnumerable<string> rowValues)
    {
        if (this.model == null)
        {
            return ValueTask.CompletedTask;
        }

        if (this.parameterMetadata.Count == 0)
        {
            this.model.ProgressLogger.AddDebugMessage("Parameter grid not initialized.");
            return ValueTask.CompletedTask;
        }

        // Operations that affect the UI need to run on the main thread.
        this.dispatcherQueue.TryEnqueue(() =>
        {
            int column = 0;
            foreach (var value in rowValues)
            {
                if (column >= this.parameterMetadata.Count)
                {
                    break;
                }

                // TODO: investigate - this can happen if the profile contains
                // and unsupported parameter, but logger.StartLogging should
                // have thrown an exception - how did we get here?
                if (value == null)
                {
                    continue;
                }

                var rowMetadata = this.parameterMetadata[column];
                rowMetadata.Value.Text = value + " " + rowMetadata.Units;
                if (rowMetadata.ZoomedValue?.Text != null)
                {
                    rowMetadata.ZoomedValue.Text = value;
                }

                column++;
            }

            if ((column > 0) && this.ErrorMessage.Visibility == Visibility.Visible)
            {
                this.ErrorMessage.Visibility = Visibility.Collapsed;
                this.Controls.Visibility = Visibility.Visible;
            }
        });

        return ValueTask.CompletedTask;
    }

    private async void ParameterGrid_DoubleTapped(object sender, Microsoft.UI.Xaml.Input.DoubleTappedRoutedEventArgs e)
    {
        FrameworkElement? element = e.OriginalSource as FrameworkElement;
        Border? border = null;
        if (element is TextBlock)
        {
            border = element.Parent as Border;
        }

        if (element is Border)
        {
            border = element as Border;
        }

        if (border == null)
        {
            return;
        }

        if (this.model == null)
        {
            return;
        }

        // get the row of the Border in the grid
        int rowIndex = Grid.GetRow(border);
        string? parentName = (border.Parent as Grid)?.Name;
        if (parentName == "Parameters")
        {
            var metadata = this.parameterMetadata.Find(x => (rowIndex) == x?.Indices?.MainRowIndex);
            if (metadata != null && metadata.DataSource != null)
            {
                await (this.model?.EditParameter(metadata.DataSource) ?? Task.CompletedTask);
            }
        }

        if (parentName == "ZoomedParameters")
        {
            var metadata = this.parameterMetadata.Find(x => rowIndex == x?.Indices?.ZoomRowIndex);
            if (metadata != null)
            {
                this.model?.EditParameter(metadata.DataSource);
            }
        }
    }

    private ValueTask ShowErrorMessage(string message)
    {
        this.dispatcherQueue.TryEnqueue(() =>
        {
            this.Controls.Visibility = Visibility.Collapsed;
            this.ErrorMessage.Visibility = Visibility.Visible;
            this.ErrorMessage.Text = message;
        });

        return ValueTask.CompletedTask;
    }
}

